from PySide6 import QtWidgets


class ocrreader(QtWidgets.QApplication):
    def __init__(self, argv) -> None:
        super().__init__(argv)
